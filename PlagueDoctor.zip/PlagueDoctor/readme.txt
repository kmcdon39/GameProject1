Game Name: Plague Dungeon
Ready to Die Studio Members: Joel Hall, Chase Auzenne, Tony Teddy,
Kevin McDonald

How to Play: Use the arrow keys to move around the dungeon and avoid enemies.
The goal is to collect all 6 scrolls, with 3 scrolls per level, in order to 
collect the final potion that can save the village. There are three types of enemies,
the green enemy explodes when the player gets too close, the stationary enemy has projectiles
the player must avoid and the red enemy follows the player when the player comes within a certain distance of the enemy. The player
must collect all the scrolls in each level in order to progress to the next.

Cheat Codes: If Q is pressed, the room is restarted. If alt+N is pressed, the player can go to
the next room. If alt+B is pressed, the score is set to 6, making the final potion instantly available.

# GameProject1
Youtube video for shader code reference: https://www.youtube.com/watch?v=mVao4aP0Hg0

Youtube video for timeline code reference: https://www.youtube.com/watch?v=LczcbqeUeUE

Also referenced the Timeline and Shader pages on manual.yoyogames.com. 
Links are: https://manual.yoyogames.com/GameMaker_Language/GML_Reference/Asset_Management/Timelines/Timelines.htm  
https://manual.yoyogames.com/Additional_Information/Guide_To_Using_Shaders.htm

